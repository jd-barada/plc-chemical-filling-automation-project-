# Resume / CV Project Description

PLC Bottle Filling Automation System | Industrial Control Project

Designed and implemented a PLC-based automated bottle filling system using ladder logic programming.

Key Responsibilities:
- Developed sequential control logic using SET/RESET architecture.
- Implemented timer-based filling mechanism.
- Designed interlocked conveyor and valve control system.
- Simulated industrial bottle sensing and automated filling process.
- Structured ladder logic for modular and scalable automation.

Technical Skills Used:
- PLC Programming
- Ladder Logic Design
- Industrial Automation
- Timer & Sequential Control Systems
- Process Automation

Outcome:
Successfully simulated a real-time bottle filling automation workflow demonstrating core industrial control engineering principles.
