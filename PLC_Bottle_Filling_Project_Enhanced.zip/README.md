# 🚀 PLC Bottle Filling Automation Project

![PLC Automation](images/project_banner.png)

## 📌 Project Summary

This project demonstrates an industrial **Bottle Filling Automation System** implemented using **PLC Ladder Logic Programming**.

The system automates bottle detection, conveyor control, timed filling operation, and automatic reset using timers and interlocking logic.

This project is ideal for:
- Automation Engineering students
- PLC beginners
- Industrial control system learners
- Core engineering portfolio building

---

## 🏭 System Architecture

### Inputs
- START Push Button (I:0.00)
- STOP Push Button (I:0.02)
- Bottle Sensor (I:0.01)

### Outputs
- START LATCH (Q:100.00)
- CONVEYOR MOTOR (Q:100.01)
- START FILLING (Q:100.02)
- VALVE CONTROL (Q:100.03)

### Timers
- T000 → 1 second delay (100ms × 10)
- T001 → 3 seconds filling time (100ms × 30)

---

## ⚙️ Working Sequence

1. Operator presses START button.
2. START LATCH is set.
3. Conveyor motor runs.
4. Bottle sensor detects bottle at filling station.
5. Filling process starts.
6. Valve opens for predefined duration.
7. After filling completes, system resets and waits for next bottle.

---

## 🧠 PLC Concepts Demonstrated

- SET & RESET logic
- Latching mechanism
- Timer operations
- Output interlocking
- Sequential automation control
- Industrial automation fundamentals

---

## 📁 Repository Structure

```
PLC_Bottle_Filling_Project/
│
├── README.md
├── images/
├── ladder_logic/
├── docs/
```

---

## 📈 Key Learning Outcomes

- Understanding real industrial PLC workflow
- Implementing timed control systems
- Designing sequential automation processes
- Industrial ladder diagram structuring

---

## 👨‍💻 Author

Barada Prasanna Roul  
Automation & Embedded Systems Enthusiast  

---

## 📜 License
MIT License
