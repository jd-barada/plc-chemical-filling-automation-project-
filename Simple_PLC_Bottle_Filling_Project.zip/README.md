# Simple PLC Bottle Filling Project

## 📌 Project Overview
This project demonstrates a simple PLC-based bottle filling system using Ladder Logic.

The system includes:
- Start Push Button (START PB)
- Stop Push Button (STOP PB)
- Bottle Sensing Sensor
- Conveyor Output
- Filling Valve Control
- Timers for filling duration

## ⚙️ Working Principle

1. Press START PB → START LATCH is set.
2. Conveyor runs.
3. When bottle sensor detects bottle → Filling process starts.
4. Timer T000 controls initial delay.
5. Timer T001 controls filling duration.
6. Valve opens during filling time.
7. After filling completes → Filling resets.

## 🧠 PLC Address Mapping

| Signal | Address |
|--------|---------|
| START PB | I:0.00 |
| STOP PB | I:0.02 |
| BOTTLE SENSOR | I:0.01 |
| START LATCH | Q:100.00 |
| CONVEYOR OUTPUT | Q:100.01 |
| START FILLING | Q:100.02 |
| VALVE OPEN | Q:100.03 |
| TIMER T000 | #10 (100ms base) |
| TIMER T001 | #30 (100ms base) |

## 📁 Folder Structure

- images/ → Ladder logic screenshots
- ladder_logic/ → Ladder logic explanation file
- docs/ → Working explanation document

## 🎯 Applications
- Industrial automation
- Liquid filling systems
- Packaging industries
- PLC training project

---
Created by: Barada Prasanna Roul
