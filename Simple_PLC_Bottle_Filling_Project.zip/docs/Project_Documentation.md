# Project Documentation

## System Description
This PLC project simulates a basic bottle filling automation system.

## Components Used
- PLC Software (Omron/Generic Ladder Software)
- Push Buttons
- Bottle Detection Sensor
- Conveyor Motor
- Solenoid Valve

## Sequence of Operation
1. Operator presses START button.
2. Conveyor moves bottle.
3. Sensor detects bottle position.
4. Filling valve opens for fixed time.
5. Valve closes automatically.
6. System ready for next bottle.

## Learning Outcomes
- Understanding SET & RESET logic
- Working with timers
- Output interlocking
- Industrial automation fundamentals
